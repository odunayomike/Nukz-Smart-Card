<?php 
    include("conn.php");
   
    if(session_id() == ''){
        //session has not started
        session_start();
    }

    if (!isset($_SESSION['loggedin'])) {
    header('Location: login.php');
    exit;
    }
    if ($_SESSION['user_type'] == 'user') {
    echo "you are not authorised to access this page";

    exit;
    }

    if ($_SESSION['status'] == 'suspended') {
    echo '<script>alert("Your admin access have been suspended");</script>';

    exit;
    }

      $errors = array(); 

    $user_id = $_SESSION['user_id'];
    //include("login-handler.php");
    $currentPage = 'dashboard';
    
    if (isset($_SESSION['username'])){
        include("admin-header.php");
        //echo $_SESSION["user_id"];
    }
?>



<div class="user-content-body">
    <div class="user-sidebar">
        <div class="side-icon user-active" style="text-align: center; display: flex; margin-bottom: 10px">
            <div class="V-card">
                <i class="bi bi-person-vcard-fill"></i>
            </div>
            <a href="index.php">
                <div style="margin-left: 10px;">
                    <p>Overview</p>
                </div>
            </a>
        </div>

        <div class="side-icon" style="text-align: center; display: flex; margin-bottom: 10px">

            <div class="V-card">
                <i class="bi bi-bar-chart-fill"></i>
            </div>
            <a class="active" href="analytics.php">
                <div style="margin-left: 10px;">
                    <p>Analytics</p>
                </div>
            </a>

        </div>

        <div class="side-icon" style="text-align: center; display: flex; margin-bottom: 10px">

            <div class="V-card">
                <i class="bi bi-question-lg"></i>
            </div>
            <div style="margin-left: 10px;">
                <p>Help</p>
            </div>


        </div>

        <div class="side-icon" style="text-align: center; display: flex; margin-bottom: 10px">
            <div class="V-card">
                <i class="bi bi-gear-fill"></i>
            </div>
            <div style="margin-left: 10px;">
                <p>Settings</p>
            </div>
        </div>
    </div>

    <div style="width: 100%;">
        <div class="analytics-box">
            <div style="margin-left: -10px;" class="box1">
                <div class="top-head">
                    <p>Top Scans</p>
                </div>
                <table class="box">
                    <tr class="box-table-head">
                        <th style="padding: 17px;">Name</th>
                        <th>Scan</th>
                    </tr>
                    <tr style="color: #686868; font-weight: 500;">
                        <td style=" padding: 15px 27px;">Temitope Michael</td>
                        <td>20</td>
                    </tr>
                </table>
            </div>

            <div style="margin-left: 20px;" class="box1">
                <div class="top-head">
                    <p>Users with highest virtual card created</p>
                </div>
                <table class="box">
                    <tr class="box-table-head">
                        <th style="padding: 17px;">Name</th>
                        <th>Scan</th>
                    </tr>
                    <tr style="color: #686868; font-weight: 500;">
                        <td style=" padding: 15px 27px;">Temitope Michael</td>
                        <td>20</td>
                    </tr>
                </table>
            </div>

        </div>

        <div style="margin-top: -70px;" class="analytics-box">
            <div style="margin-left: -10px;" class="box1">
                <div class="top-head">
                    <p>Active Users</p>
                </div>
                <table class="box">
                    <tr class="box-table-head">
                        <th style="padding: 17px;">Name</th>
                        <th>Status</th>
                    </tr>
                    <tr style="color: #686868; font-weight: 500;">
                        <td style=" padding: 15px 27px;">Temitope Michael</td>
                        <td>Active</td>
                    </tr>
                </table>
            </div>

            <div style="margin-left: 20px;" class="box1">
                <div class="top-head">
                    <p>Suspended Users</p>
                </div>
                <table class="box">
                    <tr class="box-table-head">
                        <th style="padding: 17px;">Name</th>
                        <th>Status</th>
                    </tr>
                    <tr style="color: #686868; font-weight: 500;">
                        <td style=" padding: 15px 27px;">Temitope Michael</td>
                        <td>Suspended</td>
                    </tr>
                </table>
            </div>

        </div>

    </div>




</div>
<?php
        include("footer.php");
    ?>
<script src="../js/main.js"></script>
</body>

</html>