<footer class="main-footer">
    <div class="footer-content">
        <div class="section1">
            <div class="section1-img">
                <img style="width: 270px; " src="../img/nukdigital_logowhite.png" alt="">
            </div>



        </div>

    </div>
    <div class="footer-last-part">
        <h3 style="font-size: 15px !important;"> © copyright 2021 - 2022 by NuKreationz Digital Solutions </h3>
    </div>

</footer>

<footer class="mobile-footer">
    <div class="footer-last-part">
        <h3 style="font-size: 15px !important;"> © copyright 2021 - 2022 by NuKreationz Digital Solutions </h3>
    </div>
</footer>